#ifndef POSITIONCONTROL__H__
#define POSITIONCONTROL__H__

void pos_init(void);

#endif
