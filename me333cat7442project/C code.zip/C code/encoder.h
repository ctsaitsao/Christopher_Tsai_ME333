#ifndef ENCODER__H__
#define ENCODER__H__

int encoder_counts(void);
void encoder_init(void);
int encoder_reset(void);

#endif
