#ifndef CURRENTCONTROL__H__
#define CURRENTCONTROL__H__

#define PLOTPTS 100

void pwm_init(void);

#endif
